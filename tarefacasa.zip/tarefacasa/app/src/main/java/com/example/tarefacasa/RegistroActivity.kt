package com.example.tarefacasa

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText

class RegistroActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_registrar)

        val editLogin = findViewById<EditText>(R.id.edit_login)
        val editPassword = findViewById<EditText>(R.id.edit_password)

        val buttonConfirm = findViewById<Button>(R.id.button_confirm)
        val buttonCancel = findViewById<Button>(R.id.button_cancel)

        buttonConfirm.setOnClickListener {
            val intent = Intent(this, RegistroResultadoActivity::class.java)
            val loginValue: String = editLogin.text.toString()
            val passwordValue: String = editPassword.text.toString()

            intent.putExtra("registerOk",loginValue)
            intent.putExtra("passwordOk",passwordValue)
            startActivity(intent)
        }

        buttonCancel.setOnClickListener {
            finish()
        }
    }
}
