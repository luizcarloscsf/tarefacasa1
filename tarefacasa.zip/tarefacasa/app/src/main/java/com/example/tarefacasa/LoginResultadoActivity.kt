package com.example.tarefacasa

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView

class LoginResultadoActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login_resultado)

        val stringHello: String = getString(R.string.hello)
        val stringYourCpf: String = getString(R.string.your_cpf)
        val textOut = findViewById<TextView>(R.id.text_result)


        textOut.text = " ${stringHello} ${intent.getStringExtra("loginOk")}, \n" + " ${stringYourCpf}: ${intent.getStringExtra("passwordOk")}"
    }
}
